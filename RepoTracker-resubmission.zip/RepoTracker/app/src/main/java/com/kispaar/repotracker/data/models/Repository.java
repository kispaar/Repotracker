package com.kispaar.repotracker.data.models;

/**
 * Created by paul on 1/6/15.
 */
public class Repository {

    private String login;
    private  String Url;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }
}
