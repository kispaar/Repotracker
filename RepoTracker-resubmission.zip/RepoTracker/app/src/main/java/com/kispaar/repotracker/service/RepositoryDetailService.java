package com.kispaar.repotracker.service;

import android.app.IntentService;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.util.Log;

import com.kispaar.repotracker.data.db.RepositoryContract;
import com.kispaar.repotracker.data.models.RepositoryDetails;
import com.kispaar.repotracker.service.helpers.RepositoryJsonReadHelper;

import java.io.IOException;


public class RepositoryDetailService extends IntentService {

    private final String LOG_TAG=RepositoryDetailService.class.getSimpleName();
    public static  final String REPOSITORY_INTENT="RepositoryIntent";

    public RepositoryDetailService() {
        super("RepositoryDetailService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        handleRepositorySearch(intent);
    }


    private void handleRepositorySearch(Intent intent){

        try {

            ContentResolver cr = getContentResolver();
            int i=0;
            for (RepositoryDetails repo: RepositoryJsonReadHelper.parseJson(intent.getStringExtra(REPOSITORY_INTENT))){
                ContentValues values = new ContentValues();
                values.put(RepositoryContract.RepositoryEntry.COLUMN_ACCOUNT, repo.getAccount());
                values.put(RepositoryContract.RepositoryEntry.COLUMN_URL,intent.getStringExtra(REPOSITORY_INTENT));
                values.put(RepositoryContract.RepositoryEntry.COLUMN_DESCRIPTION, repo.getDescription());
                values.put(RepositoryContract.RepositoryEntry.COLUMN_FORKS,repo.getForks());
                values.put(RepositoryContract.RepositoryEntry.COLUMN_LAST_COMMIT_DATE,repo.getLastCommitDate());
                values.put(RepositoryContract.RepositoryEntry.COLUMN_GIT_URL,repo.getAvatarUrl());
                values.put(RepositoryContract.RepositoryEntry.COLUMN_NAME,repo.getName());
                values.put(RepositoryContract.RepositoryEntry.COLUMN_OPEN_ISSUES,repo.getOpenIssues());
                cr.insert(RepositoryContract.RepositoryEntry.CONTENT_URI,values);
                i++;

            }
            Log.e(LOG_TAG, "REPOSITORY JSON RESULT " + i);
        } catch (IOException e) {
            Log.e(LOG_TAG,"REPOSITORY JSON PARSING",e);
        }


    }
}
