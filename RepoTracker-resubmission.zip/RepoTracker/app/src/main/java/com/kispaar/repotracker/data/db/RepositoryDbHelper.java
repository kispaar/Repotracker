package com.kispaar.repotracker.data.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.kispaar.repotracker.data.db.RepositoryContract.*;


public class RepositoryDbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION =9 ;

    public static final String DATABASE_NAME = "Repo.db";


    public RepositoryDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        final String SQL_CREATE_ACCOUNT_TABLE = "CREATE TABLE " + AccountEntry.TABLE_NAME + " (" +
                AccountEntry._ID + " INTEGER PRIMARY KEY," +
                AccountEntry.COLUMN_LOGIN + " TEXT NOT NULL, " +
                AccountEntry.COLUMN_Query + " TEXT, " +
                AccountEntry.COLUMN_URL + " TEXT NOT NULL, " +
                "UNIQUE (" + AccountEntry.COLUMN_URL +") ON CONFLICT IGNORE"+
                " );";

        final String SQL_CREATE_REPOSITORY_TABLE = "CREATE TABLE " + RepositoryEntry.TABLE_NAME + " (" +
                RepositoryEntry._ID + " INTEGER PRIMARY KEY," +
                RepositoryEntry.COLUMN_ACCOUNT + " TEXT NOT NULL, " +
                RepositoryEntry.COLUMN_NAME + " TEXT NOT NULL, " +
                RepositoryEntry.COLUMN_DESCRIPTION + " TEXT NOT NULL, " +
                RepositoryEntry.COLUMN_FORKS + " INT NOT NULL, " +
                RepositoryEntry.COLUMN_OPEN_ISSUES + " INT NOT NULL, " +
                RepositoryEntry.COLUMN_GIT_URL + " TEXT, " +
                RepositoryEntry.COLUMN_URL + " TEXT NOT NULL, " +
                RepositoryEntry.COLUMN_LAST_COMMIT_DATE + " TEXT NOT NULL, " +
                " FOREIGN KEY (" + RepositoryEntry.COLUMN_ACCOUNT + ") REFERENCES " +
                AccountEntry.TABLE_NAME + " (" + AccountEntry.COLUMN_LOGIN + "), " +
                "UNIQUE (" + RepositoryEntry.COLUMN_GIT_URL +") ON CONFLICT IGNORE"+
                " );";

        final String SQL_CREATE_ISSUES_TABLE = "CREATE TABLE " + IssuesEntry.TABLE_NAME + " (" +
                IssuesEntry._ID + " INTEGER PRIMARY KEY," +
                IssuesEntry.COLUMN_STATUS + " TEXT NOT NULL, " +
                IssuesEntry.COLUMN_OPEN_DATE + " TEXT NOT NULL, " +
                IssuesEntry.COLUMN_REPOSITORY + " TEXT, " +
                IssuesEntry.COLUMN_CLOSE_DATE+ " TEXT NOT NULL, " +
                IssuesEntry.COLUMN_DESC + " TEXT NOT NULL, " +
                " FOREIGN KEY (" + IssuesEntry.COLUMN_REPOSITORY + ") REFERENCES " +
                RepositoryEntry.TABLE_NAME + " (" + RepositoryEntry.COLUMN_URL + "));";

        db.execSQL(SQL_CREATE_ACCOUNT_TABLE);
        db.execSQL(SQL_CREATE_REPOSITORY_TABLE);
        db.execSQL(SQL_CREATE_ISSUES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + AccountEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + RepositoryEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + IssuesEntry.TABLE_NAME);
        onCreate(db);
    }
}
