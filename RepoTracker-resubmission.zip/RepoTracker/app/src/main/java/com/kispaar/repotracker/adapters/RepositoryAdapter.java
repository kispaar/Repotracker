package com.kispaar.repotracker.adapters;


import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.kispaar.repotracker.R;
import com.kispaar.repotracker.data.db.RepositoryContract;

public class RepositoryAdapter extends CursorAdapter {



    public static class ViewHolder {
        public final TextView textView;
        public final ImageView imageView;

        public ViewHolder(View view) {
            textView = (TextView)view.findViewById(R.id.list_item_repo_textView);
            imageView=(ImageView)view.findViewById(R.id.imageView_user);
        }
    }




    public RepositoryAdapter(Context context, Cursor c, int flags) {
        super(context, c, flags);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        int layoutId=R.layout.list_item_repositories;

        View view = LayoutInflater.from(context).inflate(layoutId, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(view);
        view.setTag(viewHolder);

        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        ViewHolder viewHolder = (ViewHolder) view.getTag();
        view.setBackgroundResource(R.drawable.touch_selector);
        viewHolder.imageView.setImageResource(R.drawable.ic_repo);
        int titleIndex=cursor.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_NAME);
        viewHolder.textView.setText(cursor.getString(titleIndex));


    }
}
