package com.kispaar.repotracker.fragments;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.kispaar.repotracker.R;
import com.kispaar.repotracker.RepositoryActivity;
import com.kispaar.repotracker.adapters.SearchResultAdapter;
import com.kispaar.repotracker.data.db.RepositoryContract.AccountEntry;

public  class SearchResultListFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {


    private static final String[] ACCOUNT_COLUMNS ={
      AccountEntry._ID,
      AccountEntry.COLUMN_LOGIN,
      AccountEntry.COLUMN_URL,
      AccountEntry.COLUMN_Query
    };
    SearchResultAdapter mRepositoryAdapter;
    private String userName;

    private static final int ACCOUNT_LOADER = 0;

    public SearchResultListFragment() {
    }

    @Override
    public void onStart() {
        super.onStart();


    }

    @Override
    public void onResume() {
        super.onResume();

        //getActivity().setTitle("Accounts");

        getLoaderManager().restartLoader(ACCOUNT_LOADER, null, this);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getLoaderManager().initLoader(ACCOUNT_LOADER, null, this);
        userName = null;
        Intent intent=getActivity().getIntent();
        View rootView = inflater.inflate(R.layout.fragment_repo_list, container, false);

        if (intent !=null&& intent.hasExtra(intent.EXTRA_TEXT)){

            userName =intent.getStringExtra(intent.EXTRA_TEXT);
            getActivity().setTitle( " Accounts ");

        }



        mRepositoryAdapter=new SearchResultAdapter(getActivity(),null, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        ListView listView=(ListView)rootView.findViewById(R.id.list_view_repositories);
        ProgressBar progressBar = new ProgressBar(getActivity());
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL));
        progressBar.setIndeterminate(true);
        listView.setEmptyView(progressBar);

        ViewGroup root = (ViewGroup) getActivity().findViewById(android.R.id.content);
        root.addView(progressBar);


        listView.setAdapter(mRepositoryAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor cursor = mRepositoryAdapter.getCursor();

                String repo=cursor.getString(cursor.getColumnIndex(AccountEntry.COLUMN_URL));

                Intent intent=new Intent(getActivity(),RepositoryActivity.class)
                        .putExtra(Intent.EXTRA_TEXT,repo);
                Log.v("RepoUrl",repo );
                startActivity(intent);
            }
        });
        return rootView;
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        getLoaderManager().initLoader(ACCOUNT_LOADER, null, this);
        super.onActivityCreated(savedInstanceState);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        String sortOrder=AccountEntry.COLUMN_LOGIN + " ASC";
        Uri accountUri=AccountEntry.CONTENT_URI;
        String selection =AccountEntry.COLUMN_Query + " = '" +(userName)+ "'";

        return new CursorLoader(
                getActivity(),
                accountUri,
                ACCOUNT_COLUMNS,
                selection,
                null,
                sortOrder
        );


    }

    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor cursor) {
         mRepositoryAdapter.swapCursor(cursor);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader) {
       mRepositoryAdapter.swapCursor(null);
    }
}