package com.kispaar.repotracker.service.helpers;


import android.net.Uri;
import android.util.Log;

import com.kispaar.repotracker.data.models.Repository;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class SearchResultJsonHelper {



    public static String getRepoConnection(String username){
       String LOG_TAG="Url Connect";

        String json=null;
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        Uri builtUri=Uri.parse("https://api.github.com").buildUpon()
                .appendPath("search")
                .appendPath("users")
                .appendQueryParameter("q",username)
                .build();
        try {
            URL url = new URL(builtUri.toString());
             Log.v(LOG_TAG,builtUri.toString());
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            StringBuilder builder = new StringBuilder();
            reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {

                builder.append(line + "\n");
            }
            json = builder.toString();

        } catch (IOException e) {
            Log.e(LOG_TAG, "Error " + e, e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e(LOG_TAG, "Error closing stream", e);
                }
            }
        }



        return json;
    }

   public static List<Repository> parseSearchResult(String json){
       String LOG_TAG="Json Parser";
        List<Repository> results=new ArrayList<Repository>();

         try {
             JSONObject repoJson = new JSONObject(json);
             Log.v(LOG_TAG, "Body json"+repoJson.toString());

             JSONArray repoArray = repoJson.getJSONArray("items");
             for(int i = 0; i < repoArray.length(); i++) {
                 Repository repo=new Repository();
                 JSONObject repositoryObject = repoArray.getJSONObject(i);
                 repo.setLogin(repositoryObject.getString("login"));
                 repo.setUrl(repositoryObject.getString("repos_url"));
                 results.add(i,repo);
             }

         }catch (Exception e){

             Log.e(LOG_TAG, "Error parsing json", e);

         }

        return results;
   }



}
