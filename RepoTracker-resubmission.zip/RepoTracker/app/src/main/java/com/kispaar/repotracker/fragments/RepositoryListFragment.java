package com.kispaar.repotracker.fragments;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.kispaar.repotracker.R;
import com.kispaar.repotracker.adapters.RepositoryAdapter;
import com.kispaar.repotracker.data.db.RepositoryContract;
import com.kispaar.repotracker.service.RepoTrackerService;
import com.kispaar.repotracker.service.RepositoryDetailService;
import com.kispaar.repotracker.service.helpers.RepositoryJsonReadHelper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public  class RepositoryListFragment extends Fragment  implements LoaderManager.LoaderCallbacks<Cursor>{

    private static final int REPO_LOADER = 0;
    RepositoryAdapter mRepoAdapter;
    private ListView mListView;
    String mUrl;
    private int mPosition = ListView.INVALID_POSITION;
    private static final String SELECTED_KEY = "selected_position";

    private static final String[] REPOSITORY_COLUMNS ={
            RepositoryContract.RepositoryEntry._ID,
            RepositoryContract.RepositoryEntry.COLUMN_NAME,
            RepositoryContract.RepositoryEntry.COLUMN_URL,
            RepositoryContract.RepositoryEntry.COLUMN_GIT_URL

    };

    public RepositoryListFragment() {
    }

    public interface Callback {

        public void onItemSelected(String gitUrl);
    }

    @Override
    public void onStart() {
        super.onStart();
     Intent intent=getActivity().getIntent();
     Intent serviceIntent=new Intent(getActivity(), RepositoryDetailService.class);
     serviceIntent.putExtra(RepositoryDetailService.REPOSITORY_INTENT,intent.getStringExtra(intent.EXTRA_TEXT));
     getActivity().startService(serviceIntent);

    }
    @Override
    public void onResume() {
        super.onResume();
        if (mUrl != null ) {
            getLoaderManager().restartLoader(REPO_LOADER, null, this);
        }
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        getLoaderManager().initLoader(REPO_LOADER, null, this);
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        if (mPosition != ListView.INVALID_POSITION) {
            outState.putInt(SELECTED_KEY, mPosition);
        }
        super.onSaveInstanceState(outState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mRepoAdapter=new RepositoryAdapter(getActivity(),null,0);

        View rootView = inflater.inflate(R.layout.fragment_repo_list, container, false);

        getLoaderManager().initLoader(REPO_LOADER, null, this);

        mListView=(ListView)rootView.findViewById(R.id.list_view_repositories);
        ProgressBar progressBar = new ProgressBar(getActivity());
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        progressBar.setIndeterminate(true);
        mListView.setEmptyView(progressBar);

        ViewGroup root = (ViewGroup) getActivity().findViewById(android.R.id.content);
        root.addView(progressBar);

        mListView.setAdapter(mRepoAdapter);


        Intent intent=getActivity().getIntent();
        if (intent !=null&& intent.hasExtra(intent.EXTRA_TEXT)){

           mUrl=intent.getStringExtra(intent.EXTRA_TEXT);


        }

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Cursor cursor = mRepoAdapter.getCursor();
                if (cursor != null && cursor.moveToPosition(position)) {
                    ((Callback) getActivity())
                            .onItemSelected(cursor.getString(cursor.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_GIT_URL)));
                }
                mPosition = position;
            }
        });
        if (savedInstanceState != null && savedInstanceState.containsKey(SELECTED_KEY)) {

            mPosition = savedInstanceState.getInt(SELECTED_KEY);
        }

        return rootView;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        String sortOrder= RepositoryContract.RepositoryEntry.COLUMN_NAME + " ASC";
        Uri accountUri= RepositoryContract.RepositoryEntry.CONTENT_URI;
        String selection = RepositoryContract.RepositoryEntry.COLUMN_URL + " = '" +(mUrl)+ "'";

        return new CursorLoader(
                getActivity(),
                accountUri,
                REPOSITORY_COLUMNS,
                selection,
                null,
                sortOrder
        );
    }

    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor cursor) {
        mRepoAdapter.swapCursor(cursor);

        Log.v("SIZE OF CURSOR ","count "+cursor.getCount());

        if (mPosition != ListView.INVALID_POSITION) {

            mListView.smoothScrollToPosition(mPosition);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader) {
        mRepoAdapter.swapCursor(null);
    }




}