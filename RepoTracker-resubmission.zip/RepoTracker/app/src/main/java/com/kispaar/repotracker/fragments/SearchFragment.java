package com.kispaar.repotracker.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kispaar.repotracker.R;
import com.kispaar.repotracker.SearchResultListActivity;
import com.kispaar.repotracker.service.RepoTrackerService;

public class SearchFragment extends Fragment {

    public SearchFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        Button searchBtn=(Button)rootView.findViewById(R.id.search_button);
        final EditText searchEditText=(EditText)rootView.findViewById(R.id.search_text);


        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String search= searchEditText.getText().toString();
                if(!search.isEmpty()){

                Intent serviceIntent = new Intent(getActivity(), RepoTrackerService.class);
                serviceIntent.putExtra(Intent.EXTRA_TEXT,search);
                getActivity().startService(serviceIntent);

                Intent intent=new Intent(getActivity(),SearchResultListActivity.class)
                        .putExtra(Intent.EXTRA_TEXT,search);
                startActivity(intent);
                }else{
                    Toast.makeText(getActivity(),
                            R.string.Empty_search, Toast.LENGTH_SHORT).show();
                }
            }
        });
        return rootView;
    }


}