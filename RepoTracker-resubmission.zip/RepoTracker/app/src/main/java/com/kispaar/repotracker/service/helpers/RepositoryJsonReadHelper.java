package com.kispaar.repotracker.service.helpers;


import android.annotation.TargetApi;
import android.content.ContentValues;
import android.os.Build;
import android.util.JsonReader;
import android.util.Log;


import com.kispaar.repotracker.data.db.RepositoryContract;
import com.kispaar.repotracker.data.models.Repository;
import com.kispaar.repotracker.data.models.RepositoryDetails;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class RepositoryJsonReadHelper {



    public static List<RepositoryDetails> parseJson(String repoUrl) throws IOException {
         String LOG_TAG = "Url Connect";

         HttpURLConnection connection = null;
         InputStream inputStream = null;
         JsonReader reader=null;
         List<RepositoryDetails> list=new ArrayList();

         try {
             URL url = new URL(repoUrl);
             connection = (HttpURLConnection) url.openConnection();
             connection.setRequestMethod("GET");

             connection.connect();
             inputStream = connection.getInputStream();

             reader = new JsonReader(new InputStreamReader(inputStream, "UTF-8"));
             list= readRepositoriesArray(reader);

         } catch (IOException e) {
             Log.e(LOG_TAG, "Error " + e, e);
         } finally {
             if (connection != null && reader !=null) {
                 connection.disconnect();
                 reader.close();
             }

         }

         return list;

     }

    public static List<RepositoryDetails> readRepositoriesArray(JsonReader reader) throws IOException {
        List<RepositoryDetails> repositories = new ArrayList();

        reader.beginArray();
        while (reader.hasNext()) {
            repositories.add(readRepositoryValues(reader));
        }
        reader.endArray();
        return repositories;
    }

    private static RepositoryDetails readRepositoryValues(JsonReader reader) throws IOException {


        ContentValues values=new ContentValues();
        RepositoryDetails repository=new RepositoryDetails();

        reader.beginObject();
        while (reader.hasNext()) {
            String name = reader.nextName();
            if(name.equalsIgnoreCase("git_url")){
                repository.setAvatarUrl(reader.nextString());

            }else if(name.equalsIgnoreCase("name")){
                repository.setName(reader.nextString());

            }else if(name.equalsIgnoreCase("open_issues_count")){
                repository.setOpenIssues(reader.nextInt());

            }else if(name.equalsIgnoreCase("forks")){
                repository.setForks(reader.nextInt());

            }else if(name.equalsIgnoreCase("description")){
                repository.setDescription(reader.nextString());

            }
            else if(name.equalsIgnoreCase("updated_at")){
                repository.setLastCommitDate(reader.nextString());

            }
            else if(name.equalsIgnoreCase("owner")){

                repository.setAccount(readOwnerLogin(reader));

            }
            else{
                reader.skipValue();
            }

        }
        reader.endObject();
        return repository;
    }
  private static String readOwnerLogin(JsonReader reader) throws IOException {
      String login=null;

      reader.beginObject();

      while (reader.hasNext()) {
          String name = reader.nextName();
          if (name.equals("login")) {
            login=reader.nextString();
          }else{
              reader.skipValue();

          }

      }
      reader.endObject();

       return  login;
  }

}


