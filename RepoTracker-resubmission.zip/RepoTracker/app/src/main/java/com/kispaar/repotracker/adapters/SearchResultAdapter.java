package com.kispaar.repotracker.adapters;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kispaar.repotracker.R;
import com.kispaar.repotracker.data.db.RepositoryContract;

import java.util.List;


public class SearchResultAdapter extends CursorAdapter {



    public SearchResultAdapter(Context context, Cursor c, int flags) {
        super(context, c, flags);
    }

    public static class ViewHolder {
        public final TextView textView;
        public final ImageView imageView;

        public ViewHolder(View view) {
          textView = (TextView)view.findViewById(R.id.list_item_repo_textView);
          imageView=(ImageView)view.findViewById(R.id.imageView_user);
        }
    }



    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {

        int layoutId=R.layout.list_item_repositories;

        View view = LayoutInflater.from(context).inflate(layoutId, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        view.setTag(viewHolder);

        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        ViewHolder viewHolder = (ViewHolder) view.getTag();

        viewHolder.imageView.setImageResource(R.drawable.ic_user);
        int titleIndex=cursor.getColumnIndex(RepositoryContract.AccountEntry.COLUMN_LOGIN);
        viewHolder.textView.setText(cursor.getString(titleIndex));



    }


}
