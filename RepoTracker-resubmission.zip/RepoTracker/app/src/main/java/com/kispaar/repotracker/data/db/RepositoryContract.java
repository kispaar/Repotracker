package com.kispaar.repotracker.data.db;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;

public class RepositoryContract {

    public static final String CONTENT_AUTHORITY = "com.kispaar.repotracker.data";

    public static final String PATH_ACCOUNT = "account";
    public static final String PATH_REPOSITORY = "repository";
    public static final String PATH_ISSUES = "issue";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);


    public static final class AccountEntry implements BaseColumns {
        public static final Uri CONTENT_URI =
                BASE_CONTENT_URI.buildUpon().appendPath(PATH_ACCOUNT).build();

        public static final String CONTENT_TYPE =
                "vnd.android.cursor.dir/" + CONTENT_AUTHORITY + "/" + PATH_ACCOUNT;
        public static final String CONTENT_ITEM_TYPE =
                "vnd.android.cursor.item/" + CONTENT_AUTHORITY + "/" + PATH_ACCOUNT;


        // Table name
        public static final String TABLE_NAME = "Account";


        public static final String COLUMN_LOGIN = "login";

        public static final String COLUMN_Query= "query";
        public static final String COLUMN_URL = "url";


        public static Uri buildUri(long id) {

            return ContentUris.withAppendedId(CONTENT_URI, id);
        }

        public static String getAccountFromUri(Uri uri) {
            return uri.getPathSegments().get(1);
        }

        public static Uri buildAccountWithRepository(String account) {
            return CONTENT_URI.buildUpon().appendPath(account).build();
        }

        public static Uri buildAccountByQueryUri(String s) {
            return null;
        }
    }

     public  static final class RepositoryEntry implements BaseColumns{

         public static final Uri CONTENT_URI =
                 BASE_CONTENT_URI.buildUpon().appendPath(PATH_REPOSITORY).build();

         public static final String CONTENT_TYPE =
                 "vnd.android.cursor.dir/" + CONTENT_AUTHORITY + "/" + PATH_REPOSITORY;
         public static final String CONTENT_ITEM_TYPE =
                 "vnd.android.cursor.item/" + CONTENT_AUTHORITY + "/" + PATH_REPOSITORY;


         public static final String TABLE_NAME = "Repository";

         public static final String COLUMN_NAME="name";
         public static final String COLUMN_URL="url";
         public static final String COLUMN_DESCRIPTION="description";
         public static final String COLUMN_OPEN_ISSUES="openIssues";
         public static final String COLUMN_FORKS ="closedIssues";
         public static final String COLUMN_ACCOUNT="account";
         public static final String COLUMN_GIT_URL ="avatar_url";
         public static final String COLUMN_LAST_COMMIT_DATE="last_commit_date";

         public static Uri buildUri(long id) {
             return ContentUris.withAppendedId(CONTENT_URI, id);
         }


         public static Uri buildRepositoryWithIssues(String repository) {
             return CONTENT_URI.buildUpon().appendPath(repository).build();
         }
     }

     public  static final class IssuesEntry implements BaseColumns{

         public static final Uri CONTENT_URI =
                 BASE_CONTENT_URI.buildUpon().appendPath(PATH_ISSUES).build();

         public static final String CONTENT_TYPE =
                 "vnd.android.cursor.dir/" + CONTENT_AUTHORITY + "/" + PATH_ISSUES;
         public static final String CONTENT_ITEM_TYPE =
                 "vnd.android.cursor.item/" + CONTENT_AUTHORITY + "/" + PATH_ISSUES;


         public static final String TABLE_NAME = "Issue";

         public static final String COLUMN_DESC="description";
         public static final String COLUMN_STATUS="status";
         public static final String COLUMN_OPEN_DATE="open_date";
         public static final String COLUMN_CLOSE_DATE="close_date";
         public static final String COLUMN_REPOSITORY="repository";


         public static Uri buildUri(long id) {
             return ContentUris.withAppendedId(CONTENT_URI, id);
         }
     }

}
