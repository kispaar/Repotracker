package com.kispaar.repotracker.data.contentProviders;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

import com.kispaar.repotracker.data.db.RepositoryContract;
import com.kispaar.repotracker.data.db.RepositoryDbHelper;

public class RepositoryProvider extends ContentProvider {

    private RepositoryDbHelper dbHelper=null;
    private static final UriMatcher sUriMatcher = buildUriMatcher();

    private static final int ACCOUNTS = 100;
    private static final int ACCOUNT_WITH_REPOSITORIES = 101;

    private static final int REPOSITORY_WITH_ISSUES = 300;
    private static final int REPOSITORY = 301;

    private static final int ISSUES= 400;

    private static final SQLiteQueryBuilder sRepositoryByAccountBuilder;
    private static final SQLiteQueryBuilder sIssueByRepositoryBuilder;

    static {
        sRepositoryByAccountBuilder=new SQLiteQueryBuilder();
        sRepositoryByAccountBuilder.setTables(RepositoryContract.AccountEntry.TABLE_NAME + " INNER JOIN " +
                RepositoryContract.RepositoryEntry.TABLE_NAME +
                " ON " + RepositoryContract.AccountEntry.TABLE_NAME +
                "." + RepositoryContract.AccountEntry.COLUMN_LOGIN +
                " = " + RepositoryContract.RepositoryEntry.TABLE_NAME +
                "." + RepositoryContract.RepositoryEntry.COLUMN_ACCOUNT);

    }
    static{
        sIssueByRepositoryBuilder=new SQLiteQueryBuilder();
        sIssueByRepositoryBuilder.setTables(RepositoryContract.RepositoryEntry.TABLE_NAME + " INNER JOIN " +
                RepositoryContract.IssuesEntry.TABLE_NAME +
                " ON " + RepositoryContract.RepositoryEntry.TABLE_NAME +
                "." + RepositoryContract.RepositoryEntry.COLUMN_URL +
                " = " + RepositoryContract.IssuesEntry.TABLE_NAME +
                "." + RepositoryContract.IssuesEntry.COLUMN_REPOSITORY);

    }


    private Cursor getRepositoryByAccount(Uri uri, String[] projection,String selection, String sortOrder){

        String account= RepositoryContract.AccountEntry.getAccountFromUri(uri);
        String[] selectionArgs=new String[]{account};

        return sRepositoryByAccountBuilder.query(dbHelper.getReadableDatabase(),projection,selection,selectionArgs,null,null,sortOrder);
    }

    private Cursor getIssuesByRepository(Uri uri, String[] projection,String selection, String sortOrder){
        String repository= uri.getPathSegments().get(1);
        String[] selectionArgs=new String[]{repository};

        return sIssueByRepositoryBuilder.query(dbHelper.getReadableDatabase(),projection,selection,selectionArgs,null,null,sortOrder);
    }

    public RepositoryProvider() {
    }

    private  static UriMatcher buildUriMatcher(){

        final UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        final String authority= RepositoryContract.CONTENT_AUTHORITY;

        matcher.addURI(authority, RepositoryContract.PATH_ACCOUNT, ACCOUNTS);
        matcher.addURI(authority,RepositoryContract.PATH_ACCOUNT+ "/*",ACCOUNT_WITH_REPOSITORIES);

        matcher.addURI(authority,RepositoryContract.PATH_REPOSITORY+"/*",REPOSITORY_WITH_ISSUES);
        matcher.addURI(authority,RepositoryContract.PATH_REPOSITORY,REPOSITORY);

        matcher.addURI(authority,RepositoryContract.PATH_ISSUES+"/*",ISSUES);


        return matcher;
    }
    @Override
    public boolean onCreate() {
        dbHelper=new RepositoryDbHelper(getContext());
        return true;
    }


    @Override
    public String getType(Uri uri) {

      final int match = sUriMatcher.match(uri);
      switch (match){
          case ACCOUNTS:
              return RepositoryContract.AccountEntry.CONTENT_TYPE;
          case ACCOUNT_WITH_REPOSITORIES:
              return RepositoryContract.AccountEntry.CONTENT_TYPE;
          case REPOSITORY_WITH_ISSUES:
              return RepositoryContract.RepositoryEntry.CONTENT_TYPE;
          case REPOSITORY:
              return RepositoryContract.RepositoryEntry.CONTENT_TYPE;
          case ISSUES:
              return RepositoryContract.IssuesEntry.CONTENT_TYPE;
          default:
              throw new UnsupportedOperationException("Unknown uri: " + uri);
      }

    }
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        final SQLiteDatabase db = dbHelper.getWritableDatabase();

        final int match = sUriMatcher.match(uri);
        Uri returnUri=null;

        switch (match) {
            case ACCOUNTS:{
                long id=db.insert(RepositoryContract.AccountEntry.TABLE_NAME,null,values);
                if(id>0) {
                    returnUri = RepositoryContract.AccountEntry.buildUri(id);

                }break;
            }
            case REPOSITORY:{
                 long id=db.insert(RepositoryContract.RepositoryEntry.TABLE_NAME,null,values);
                 if(id>0){
                     returnUri= RepositoryContract.RepositoryEntry.buildUri(id);

                 }break;
            }
            case ISSUES:{
                 long id=db.insert(RepositoryContract.IssuesEntry.TABLE_NAME,null,values);
                 if (id>0){
                     returnUri= RepositoryContract.IssuesEntry.buildUri(id);

                 }break;
            }
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }


        getContext().getContentResolver().notifyChange(uri, null);
        return returnUri;
    }


    @Override
     public Cursor query(Uri uri, String[] projection, String selection,
                         String[] selectionArgs, String sortOrder) {

        Cursor retCursor;

        switch (sUriMatcher.match(uri)) {

            case ACCOUNTS:{
                retCursor = dbHelper.getReadableDatabase().query(
                        RepositoryContract.AccountEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;
            }

            case ACCOUNT_WITH_REPOSITORIES:{
                   retCursor=getRepositoryByAccount(uri,projection,selection,sortOrder);
                break;
            }
            case REPOSITORY_WITH_ISSUES:{
                retCursor=getIssuesByRepository(uri,projection,selection,sortOrder);
                break;

            }
            case REPOSITORY:{
                retCursor = dbHelper.getReadableDatabase().query(
                        RepositoryContract.RepositoryEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;
            }
            case ISSUES:{
                retCursor = dbHelper.getReadableDatabase().query(
                        RepositoryContract.IssuesEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;
            }
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }

        retCursor.setNotificationUri(getContext().getContentResolver(), uri);
        return retCursor;

    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {

        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        final SQLiteDatabase db = dbHelper.getWritableDatabase();
        final int match = sUriMatcher.match(uri);
        int rowsDeleted;
        switch (match) {

            case ACCOUNTS:{
                rowsDeleted = db.delete(RepositoryContract.AccountEntry.TABLE_NAME,selection,selectionArgs);
                break;

            }
            case REPOSITORY:{
                rowsDeleted = db.delete(RepositoryContract.RepositoryEntry.TABLE_NAME,selection,selectionArgs);
                break;
            }
            case ISSUES:{
                rowsDeleted = db.delete(RepositoryContract.IssuesEntry.TABLE_NAME,selection,selectionArgs);
                break;
            }
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        if (selection == null || rowsDeleted != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsDeleted;
    }


     
}
