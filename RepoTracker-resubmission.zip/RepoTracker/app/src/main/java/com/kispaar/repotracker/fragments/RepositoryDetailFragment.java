package com.kispaar.repotracker.fragments;


import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.kispaar.repotracker.R;
import com.kispaar.repotracker.UserRepoDetailActivity;
import com.kispaar.repotracker.data.db.RepositoryContract;

public  class RepositoryDetailFragment extends Fragment  implements LoaderManager.LoaderCallbacks<Cursor> {

    private static final int DETAIL_LOADER = 0;
    private static final String NAME_KEY = "gitUrl";
    private static final String[] REPOSITORY_COLUMNS ={
            RepositoryContract.RepositoryEntry._ID,
            RepositoryContract.RepositoryEntry.COLUMN_NAME,
            RepositoryContract.RepositoryEntry.COLUMN_DESCRIPTION,
            RepositoryContract.RepositoryEntry.COLUMN_OPEN_ISSUES,
            RepositoryContract.RepositoryEntry.COLUMN_FORKS,
            RepositoryContract.RepositoryEntry.COLUMN_LAST_COMMIT_DATE,
            RepositoryContract.RepositoryEntry.COLUMN_GIT_URL
    } ;
    private String mGitUrl;

    private ImageView mIconView;
    private TextView  mDescriptionView;
    private TextView  mNameView;
    private TextView  mIssuesView;
    private TextView  mCommitDateView;
    private TextView  mGitUrlView;
    private TextView  mForksView;

    public RepositoryDetailFragment() {
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putString(NAME_KEY, mGitUrl);
        super.onSaveInstanceState(outState);
    }
    @Override
    public void onResume() {
        super.onResume();
        Bundle arguments = getArguments();
        if(arguments != null&&arguments.containsKey(UserRepoDetailActivity.NAME_KEY )&& mGitUrl !=null){
            getLoaderManager().restartLoader(DETAIL_LOADER, null, this);
        }

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState != null) {
            mGitUrl =savedInstanceState.getString(NAME_KEY);
        }
        Bundle arguments = getArguments();
        if (arguments != null && arguments.containsKey(UserRepoDetailActivity.NAME_KEY)) {
            getLoaderManager().initLoader(DETAIL_LOADER, null, this);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Repositories");
        Bundle arguments = getArguments();
        if (arguments != null) {
            mGitUrl = arguments.getString(UserRepoDetailActivity.NAME_KEY);
        }

        View rootView = inflater.inflate(R.layout.fragment_repo_details, container, false);
        mIconView=(ImageView)rootView.findViewById(R.id.avatar);
        mNameView=(TextView)rootView.findViewById(R.id.textView_Name);
        mDescriptionView=(TextView)rootView.findViewById(R.id.textView_description);
        mCommitDateView=(TextView)rootView.findViewById(R.id.textView_lastCommitDate);
        mIssuesView=(TextView)rootView.findViewById(R.id.open_issues_text);
        mForksView=(TextView)rootView.findViewById(R.id.forks_text);
        mGitUrlView=(TextView)rootView.findViewById(R.id.git_Url_text);

        return rootView;
    }


    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {

        Uri RepositoryUri= RepositoryContract.RepositoryEntry.CONTENT_URI;

        String selection = RepositoryContract.RepositoryEntry.COLUMN_GIT_URL + " = '" +(mGitUrl)+ "'";
        Log.v("DATA",mGitUrl.toString());
        return new CursorLoader(
                getActivity(),
                RepositoryUri,
                REPOSITORY_COLUMNS,
                selection,
                null,
                null
        );

    }

    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor data) {
         Log.v("DATA",""+data.getCount());


        if (data != null && data.moveToFirst()) {

           mNameView.setText(data.getString(data.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_NAME)));
           mDescriptionView.setText(data.getString(data.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_DESCRIPTION)));
           mGitUrlView.setText(data.getString(data.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_GIT_URL)));
           mForksView.setText(data.getString(data.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_FORKS)));
           mCommitDateView.setText(data.getString(data.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_LAST_COMMIT_DATE)));
           mIssuesView.setText(""+data.getInt(data.getColumnIndex(RepositoryContract.RepositoryEntry.COLUMN_OPEN_ISSUES)));

           mIconView.setImageResource(R.drawable.ic_repo);


        }

    }

    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader) {

    }
}